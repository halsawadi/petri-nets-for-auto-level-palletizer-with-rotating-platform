% Petri Net Toolbox   
% Version 2.4, for MATLAB 2015
% Copyright 2001-2016 PNTool Team, TU Iasi, Romania

% General information
%   pntool      - start the toolbox's GUI
