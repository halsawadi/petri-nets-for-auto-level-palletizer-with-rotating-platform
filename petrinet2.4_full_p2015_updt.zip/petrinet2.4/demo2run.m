function demo2run
% Demo 2 for Petri Net Toolbox
% Copyright 2001-2016 PNTool Team, TU Iasi, Romania

% com = sprintf('web %s ', fullfile(matlabroot,'toolbox','petrinet2.3','demos','demo2.htm'));
% eval(com);   
fd= fullfile(matlabroot,'toolbox','petrinet2.4','demos','demo2.htm');
eval(sprintf('web(''%s'')', fd));
