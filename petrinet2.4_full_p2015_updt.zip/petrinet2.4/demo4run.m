function demo4run
% Demo 4 for Petri Net Toolbox
% Copyright 2001-2016 PNTool Team, TU Iasi, Romania

% com = sprintf('web %s ', fullfile(matlabroot,'toolbox','petrinet_3','demos','demo4.htm'));
% eval(com);  
fd= fullfile(matlabroot,'toolbox','petrinet2.4','demos','demo4.htm');
eval(sprintf('web(''%s'')', fd));
