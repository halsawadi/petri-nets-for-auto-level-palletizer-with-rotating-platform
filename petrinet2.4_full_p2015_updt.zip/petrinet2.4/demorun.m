function demo(x)
% DEMOS Demo list for Petri Net Toolbox
% Copyright 2001-2016 PNTool Team, TU Iasi, Romania

switch x
    case 1,
        y = fullfile(matlabroot,'toolbox','petrinet2.4','demos','demo1.htm');
        %     web y;
        eval(sprintf('web(''%s'', ''-browser'')', y));
end
    
