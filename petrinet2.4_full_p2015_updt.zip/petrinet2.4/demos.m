function tbxStruct=demos
% DEMOS Demo list for Petri Net Toolbox
%Copyright 2001-2016 PNTool Team, TU Iasi, Romania

if nargout==0, 
    demo 'toolbox' 'Petri Net Toolbox'; 
    return;
end

tbxStruct.Name='Petri Net Toolbox';
tbxStruct.Type='Toolbox';

tbxStruct.Help={
    'The current version of the Petri Net Toolbox'
    'is accompanied by four movies'
    'illustrating its usage in the simulation,'
    'analysis and design of discrete-event systems.'};

tbxStruct.DemoList={
    'Demo 1: Computer system with two processors sharing two disks','demo1run','',...
    'Demo 2: Manufacturing system with a sequentially shared robot','demo2run','',...
    'Demo 3: Flow-shop system with three machines','demo3run','',...
    'Demo 4: Open markovian queueing network','demo4run',''};
return